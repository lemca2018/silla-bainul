package com.example.sillajohn.doximity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.util.ArrayList;
import java.util.List;

public class CategorySearch extends AppCompatActivity {
    MaterialSearchView searchView;
    ListView lstView;
    int[] cid;
    String[] cname;
    ArrayList<String> list = new ArrayList<String>();
    Doctor college=new Doctor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_search);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar1);
//        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Doctor Search");
        toolbar.setTitleTextColor(Color.parseColor("#ffffff"));
        lstView=(ListView)findViewById(R.id.lstView1);

        Intent in=getIntent();
        String s=in.getStringExtra("category");
        Toast.makeText(CategorySearch.this,s,Toast.LENGTH_SHORT).show();


        dbHelp dbH=new dbHelp(getApplicationContext());
        SQLiteDatabase db=dbH.getWritableDatabase();

        Cursor cur = db.rawQuery("select * from Doctor where category='"+s+"'", null);
        if(cur.getCount()!=0) {
            cur.moveToFirst();
            int c=cur.getCount();
            cid = new int[c];
            cname = new String[c];
            for(int i=0;i<c;i++) {
                String nm = cur.getString(cur.getColumnIndex("dname"));
                int id = cur.getInt(cur.getColumnIndex("did"));
                list.add(nm);
                cur.moveToNext();
                try
                {
                    cid[i]=id;
                    cname[i]=nm;
                }catch(ArrayIndexOutOfBoundsException e){}
            }
            ArrayAdapter<String> ada = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
            lstView.setAdapter(ada);

        }

//        ArrayAdapter<String> ada = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
//        lstView.setAdapter(ada);



//        lstView=(ListView)findViewById(R.id.lstView);
//        ArrayAdapter adapter=new ArrayAdapter(this,android.R.layout.simple_expandable_list_item_1,lstSource);
//        lstView.setAdapter(adapter);


        searchView=(MaterialSearchView)findViewById(R.id.search_view1);

        searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {

            @Override
            public void onSearchViewShown() {

            }

            @Override
            public void onSearchViewClosed() {
                //if closed search view ,lstview will return default
                lstView=(ListView)findViewById(R.id.lstView);
                ArrayAdapter adapter=new ArrayAdapter(CategorySearch.this,android.R.layout.simple_expandable_list_item_1,list);
                lstView.setAdapter(adapter);
            }
        });

        searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText !=null && !newText.isEmpty()) {
                    List<String> lstFound=new ArrayList<String>();
                    for(String item:list){
                        if (item.contains(newText))
                            lstFound.add(item);
                    }
                    ArrayAdapter adapter=new ArrayAdapter(CategorySearch.this,android.R.layout.simple_expandable_list_item_1,lstFound);
                    lstView.setAdapter(adapter);
                }
                else {
                    //if search text is null
                    //return default
                    ArrayAdapter adapter=new ArrayAdapter(CategorySearch.this,android.R.layout.simple_expandable_list_item_1,list);
                    lstView.setAdapter(adapter);
                }
                return true;
            }
        });
        lstView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String s=  cname[position];
                int i=   cid[position];
                dbHelp db=new dbHelp(getApplicationContext());
                db.tempInsert(s,i);

//                dbHelp dbH=new dbHelp(getApplicationContext());
//                SQLiteDatabase db1=dbH.getWritableDatabase();
//                Cursor c= db1.query(dbHelp.TABLE_NAME1, null, null, null, null, null,dbHelp.TID, null);
//                StringBuffer buffer=new StringBuffer();
//                while(c.moveToNext())
//                {
//                    buffer.append(" id:"+c.getString(c.getColumnIndex("id"))+"\n");
//                    buffer.append(" name:"+c.getString(c.getColumnIndex("name"))+"\n");
//                }
//                Toast.makeText(CategorySearch.this,buffer.toString(),Toast.LENGTH_SHORT).show();
                Intent in=new Intent(CategorySearch.this,DocInfo.class);
                startActivity(in);


            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item,menu);
        MenuItem item=menu.findItem(R.id.action_search);
        searchView.setMenuItem(item);
        return true;
    }


}
