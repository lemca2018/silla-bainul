package com.example.sillajohn.doximity;

/**
 * Created by Silla John on 4/6/2017.
 */

public class Contact {
    String location;
    int contact;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getContact() {
        return contact;
    }

    public void setContact(int contact) {
        this.contact = contact;
    }
}
