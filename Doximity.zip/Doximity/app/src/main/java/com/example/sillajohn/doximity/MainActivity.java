package com.example.sillajohn.doximity;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.example.sillajohn.doximity.R.id.toolbar;

public class MainActivity extends AppCompatActivity {
    Button b1,b2;
    Spinner cat;
    int currentItem = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cat = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> catadapter = ArrayAdapter.createFromResource(this,R.array.cat_array, android.R.layout.simple_spinner_item);
        catadapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        cat.setAdapter(catadapter);



        b1=(Button)findViewById(R.id.button);
        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,SearchActivity.class);
                startActivity(intent);
            }
        });

        b2=(Button)findViewById(R.id.button2);
        b2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,AddingActivity.class);
                startActivity(intent);
            }
        });

        cat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(currentItem == position){
                    return; //do nothing
                }
                else
                {
                    String s = cat.getSelectedItem().toString();
                    Intent in=new Intent(MainActivity.this,CategorySearch.class);
                    in.putExtra("category",s);
                    startActivity(in);
//                    Toast.makeText(MainActivity.this,s,Toast.LENGTH_SHORT).show();
                }
                currentItem = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

}
