package com.example.sillajohn.doximity;

/**
 * Created by Silla John on 4/5/2017.
 */

public class Doctor {
    String name;
    int id;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
