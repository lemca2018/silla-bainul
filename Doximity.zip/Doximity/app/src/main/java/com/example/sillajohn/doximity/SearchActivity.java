package com.example.sillajohn.doximity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.support.annotation.ColorInt;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.miguelcatalan.materialsearchview.MaterialSearchView;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {
    MaterialSearchView searchView;
    ListView lstView;
    int[] cid;
    String[]cname;
    ArrayList<String> list = new ArrayList<String>();
    ArrayList<Doctor> listdoctor = new ArrayList<Doctor>();
    Doctor college=new Doctor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Doctor Search");
        toolbar.setTitleTextColor(Color.parseColor("#ffffff"));
        lstView=(ListView)findViewById(R.id.lstView);




        dbHelp db=new dbHelp(this);
        listdoctor=db.getSearch();
        for (int i=0;i<listdoctor.size();i++){
//            cid[i]=listdoctor.get(i).getId();
//            cname[i]=listdoctor.get(i).getName();
            list.add(listdoctor.get(i).getName());
        }
        ArrayAdapter<String> ada = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        lstView.setAdapter(ada);



//        lstView=(ListView)findViewById(R.id.lstView);
//        ArrayAdapter adapter=new ArrayAdapter(this,android.R.layout.simple_expandable_list_item_1,lstSource);
//        lstView.setAdapter(adapter);


        searchView=(MaterialSearchView)findViewById(R.id.search_view);

        searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {

            @Override
            public void onSearchViewShown() {

            }

            @Override
            public void onSearchViewClosed() {
                //if closed search view ,lstview will return default
                lstView=(ListView)findViewById(R.id.lstView);
                ArrayAdapter adapter=new ArrayAdapter(SearchActivity.this,android.R.layout.simple_expandable_list_item_1,list);
                lstView.setAdapter(adapter);
            }
        });

        searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText !=null && !newText.isEmpty()) {
                    List<String> lstFound=new ArrayList<String>();
                    for(String item:list){
                        if (item.contains(newText))
                            lstFound.add(item);
                    }
                    ArrayAdapter adapter=new ArrayAdapter(SearchActivity.this,android.R.layout.simple_expandable_list_item_1,lstFound);
                    lstView.setAdapter(adapter);
                }
                else {
                    //if search text is null
                    //return default
                    ArrayAdapter adapter=new ArrayAdapter(SearchActivity.this,android.R.layout.simple_expandable_list_item_1,list);
                    lstView.setAdapter(adapter);
                }
                return true;
            }
        });
        lstView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override

            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                String s=   listdoctor.get(position).getName();
                int i=   listdoctor.get(position).getId();
                dbHelp db=new dbHelp(getApplicationContext());
                db.tempInsert(s,i);

                dbHelp dbH=new dbHelp(getApplicationContext());
                SQLiteDatabase db1=dbH.getWritableDatabase();
                Cursor c= db1.query(dbHelp.TABLE_NAME1, null, null, null, null, null,dbHelp.TID, null);
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append(" id:"+c.getString(c.getColumnIndex("id"))+"\n");
                    buffer.append(" name:"+c.getString(c.getColumnIndex("name"))+"\n");
                }
                Toast.makeText(SearchActivity.this,buffer.toString(),Toast.LENGTH_SHORT).show();
                Intent in=new Intent(SearchActivity.this,DocInfo.class);
                startActivity(in);


            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_item,menu);
        MenuItem item=menu.findItem(R.id.action_search);
        searchView.setMenuItem(item);
        return true;
    }
}