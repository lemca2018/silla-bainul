package com.example.sillajohn.doximity;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

/**
 * Created by Silla John on 4/5/2017.
 */

public class dbHelp extends SQLiteOpenHelper {
    public static final String  DB_NAME="doximity";
    public static final int VERSION_NO=1;
    public static final String TABLE_NAME="Doctor";
    public static final String TABLE_NAME1="Temp";
    public static final String ID="did";
    public static final String NAME="dname";
    public static final String QUALIFICATION="qualification";
    public static final String CATEGORY="category";
    public static final String HOSPITALNAME="hospital";
    public static final String LOCATION="location";
    public static final String ATIME="availabletime";
    public static final String CONTACT="contact";

    public static final String TID="id";
    public static final String TNAME="name";

    public dbHelp(Context context) {

        super(context, DB_NAME, null, VERSION_NO);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createDoctor= "CREATE TABLE " + TABLE_NAME +" ("+ ID +" INTEGER PRIMARY KEY, " + NAME + " TEXT, " +
                ""+ QUALIFICATION +" TEXT , " + CATEGORY +" TEXT , "+ HOSPITALNAME +" TEXT , " +
                ""+ LOCATION +" TEXT, "+ ATIME +" TEXT , "+ CONTACT  + ")";
        db.execSQL(createDoctor);

        String createTemp1= "CREATE TABLE "+ TABLE_NAME1 +" ("+ TID +" INTEGER ," +
                ""+ TNAME +" TEXT, FOREIGN KEY("+ TID +") REFERENCES "+ TABLE_NAME +"("+ ID +"))";
        db.execSQL(createTemp1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public ArrayList<Doctor> getSearch() {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cur = db.rawQuery("select dname,did from Doctor", null);
        ArrayList<Doctor> dlist = new ArrayList<Doctor>();

        if(cur.getCount()!=0) {
            cur.moveToFirst();
            int c = cur.getCount();
            int[] cid = new int[c];
            String[] cname = new String[c];
            for (int i = 0; i < c; i++) {
                Doctor doc=new Doctor();
                String nm = cur.getString(cur.getColumnIndex("dname"));
                int id = cur.getInt(cur.getColumnIndex("did"));
                doc.setId(id);
                doc.setName(nm);
                cur.moveToNext();
                dlist.add(doc);
            }
            return dlist;
        }

        return null;
    }
    public void tempInsert(String name,int id) {
        SQLiteDatabase db=this.getWritableDatabase();
        db.execSQL("delete from '"+TABLE_NAME1+"'");
        db.execSQL("insert into '"+TABLE_NAME1+"' values('"+id+"','"+name+"');");
    }
    public ArrayList<Contact> getContact() {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cur = db.rawQuery("select * from Doctor,Temp where Doctor.did=Temp.id", null);
        ArrayList<Contact> clist = new ArrayList<Contact>();
        if(cur.getCount()!=0) {
            cur.moveToFirst();
            int c = cur.getCount();
            for (int i = 0; i < c; i++) {
                Contact con=new Contact();
                String loc = cur.getString(cur.getColumnIndex("location"));
                int contact = cur.getInt(cur.getColumnIndex("contact"));
                con.setContact(contact);
                con.setLocation(loc);
                cur.moveToNext();
                clist.add(con);
            }
            return clist;
        }

        return null;
    }
    public ArrayList<PersonaDetails> getPersonInfo() {
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cur = db.rawQuery("select Doctor.dname,Doctor.qualification,Doctor.category,Doctor.hospital,Doctor.availabletime from Doctor,Temp where Doctor.dname=Temp.name", null);
        ArrayList<PersonaDetails> plist = new ArrayList<PersonaDetails>();
        if(cur.getCount()!=0) {
            cur.moveToFirst();
            int c = cur.getCount();
            for (int i = 0; i < c; i++) {
                PersonaDetails per=new PersonaDetails();
                String name = cur.getString(cur.getColumnIndex("dname"));
                String qual = cur.getString(cur.getColumnIndex("qualification"));
                String cat = cur.getString(cur.getColumnIndex("category"));
                String hos = cur.getString(cur.getColumnIndex("hospital"));
                String abt = cur.getString(cur.getColumnIndex("availabletime"));
                per.setName(name);
                per.setQualification(qual);
                per.setCategory(cat);
                per.setHospital(hos);
                per.setAvailabletime(abt);
                cur.moveToNext();
                plist.add(per);
            }
            return plist;
        }

        return null;
    }

}


