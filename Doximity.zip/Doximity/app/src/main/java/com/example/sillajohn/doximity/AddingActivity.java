package com.example.sillajohn.doximity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddingActivity extends AppCompatActivity {
    EditText et1,et2,et3,et4,et5,et6,et7,et8;
    Button b1,b2,b3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding);

        et1=(EditText)findViewById(R.id.editText);
        et2=(EditText)findViewById(R.id.editText2);
        et3=(EditText)findViewById(R.id.editText3);
        et4=(EditText)findViewById(R.id.editText4);
        et5=(EditText)findViewById(R.id.editText5);
        et6=(EditText)findViewById(R.id.editText6);
        et7=(EditText)findViewById(R.id.editText7);
        et8=(EditText)findViewById(R.id.editText8);

        b1=(Button)findViewById(R.id.button3);
        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dbHelp dbH=new dbHelp(getApplicationContext());
                SQLiteDatabase db=dbH.getWritableDatabase();
                Cursor c=db.rawQuery("select * from doctor where did='"+et1.getText()+"'",null);
                if ((c.moveToNext())) {
                    db.execSQL("delete from doctor where did='"+et1.getText()+"'");
                    showMessege("Success", "Record deleted");
                }
                clearText();
            }
        });
        b2=(Button) findViewById(R.id.button4);
        b2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String id=et1.getText().toString();
                String name=et2.getText().toString();
                String qual=et3.getText().toString();
                String cat=et4.getText().toString();
                String hos=et5.getText().toString();
                String loc=et6.getText().toString();
                String time=et7.getText().toString();
                String con=et8.getText().toString();

                dbHelp dbH=new dbHelp(getApplicationContext());
                SQLiteDatabase db=dbH.getWritableDatabase();

                ContentValues value=new ContentValues();
                value.put(dbHelp.ID,id);
                value.put(dbHelp.NAME,name);
                value.put(dbHelp.QUALIFICATION,qual);
                value.put(dbHelp.CATEGORY,cat);
                value.put(dbHelp.HOSPITALNAME,hos);
                value.put(dbHelp.LOCATION,loc);
                value.put(dbHelp.ATIME,time);
                value.put(dbHelp.CONTACT,con);
                long n= db.insert(dbHelp.TABLE_NAME,null,value);
                Toast.makeText(AddingActivity.this,"Inserted at" +n,Toast.LENGTH_LONG).show();
                clearText();
            }
        });
        b3=(Button)findViewById(R.id.button5);
        b3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                dbHelp dbH=new dbHelp(getApplicationContext());
                SQLiteDatabase db=dbH.getWritableDatabase();
                Cursor c= db.query(dbHelp.TABLE_NAME, null, null, null, null, null,dbHelp.ID, null);
                StringBuffer buffer=new StringBuffer();
                while(c.moveToNext())
                {
                    buffer.append(" id:"+c.getString(c.getColumnIndex("did"))+"\n");
                    buffer.append(" name:"+c.getString(c.getColumnIndex("dname"))+"\n");
                    buffer.append("Qualification:"+c.getString(c.getColumnIndex("qualification"))+"\n");
                    buffer.append("category:"+c.getString(c.getColumnIndex("category"))+"\n");
                    buffer.append("hospital:"+c.getString(c.getColumnIndex("hospital"))+"\n");
                    buffer.append("Location:"+c.getString(c.getColumnIndex("location"))+"\n");
                    buffer.append("Time:"+c.getString(c.getColumnIndex("availabletime"))+"\n");
                    buffer.append("Contact:"+c.getString(c.getColumnIndex("contact"))+"\n\n");
                }
                showMessege("Doctor details",buffer.toString());
            }
        });
    }

    public void showMessege(String title,String message) {
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
    public void clearText(){
        et1.setText("");
        et2.setText("");
        et3.setText("");
        et4.setText("");
        et5.setText("");
        et6.setText("");
        et7.setText("");
        et8.setText("");
        et1.requestFocus();
    }
}
